﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.SamanSaffari_v1._2
{
    internal class ItemSearch
    {
        public static Iitem giveItem(string name)
        {
            for(int i = 0; i < Program.itemlist.Count; i++)
            {
                if (name == Program.itemlist[i].Name)
                {
                    return Program.itemlist[i];
                }
            }
            return null;
        }
    }
}
