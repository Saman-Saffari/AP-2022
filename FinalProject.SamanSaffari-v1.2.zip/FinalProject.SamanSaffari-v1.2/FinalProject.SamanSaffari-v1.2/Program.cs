﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.SamanSaffari_v1._2
{
    internal static class Program
    {
        public static List<Iitem> itemlist=new List<Iitem>();
        public  static Assistant assistant = new Assistant();
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            itemlist.Add(new Cookie("chocolate", 15));
            itemlist.Add(new Cookie("ginger", 10));
            itemlist.Add(new Cookie("saffron", 10));
            itemlist.Add(new Cookie("raisin", 5));
            itemlist.Add(new Cookie("plain", 5));
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
