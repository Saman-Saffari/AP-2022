﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.SamanSaffari_v1._2
{
    public partial class orderwindow : Form
    {
        BindingSource bindingSource = new BindingSource();

        public orderwindow()
        {
            InitializeComponent();
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            plain.Clear();
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            ginger.Clear();
        }
        private void textBox4_Enter(object sender, EventArgs e)
        {
            chocolate.Clear();
        }
        private void textBox3_Enter(object sender, EventArgs e)
        {
            raisin.Clear();
        }
        private void textBox1_Enter(object sender, EventArgs e)
        {
            saffron.Clear();
        }



        private void orderwindow_Load(object sender, EventArgs e)
        {
            bindingSource.DataSource = Assistant.orders;
            dataGridView1.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
        }
        private void neworder_Click(object sender, EventArgs e)
        {
            List<KeyValuePair<Iitem, int>> items = new List<KeyValuePair<Iitem, int>>();
            items.Add(new KeyValuePair<Iitem, int>(ItemSearch.giveItem("plain"), Int32.Parse(plain.Text)));
            items.Add(new KeyValuePair<Iitem, int>(ItemSearch.giveItem("saffron"), Int32.Parse(saffron.Text)));
            items.Add(new KeyValuePair<Iitem, int>(ItemSearch.giveItem("chocolate"), Int32.Parse(chocolate.Text)));
            items.Add(new KeyValuePair<Iitem, int>(ItemSearch.giveItem("raisin"), Int32.Parse(raisin.Text)));
            items.Add(new KeyValuePair<Iitem, int>(ItemSearch.giveItem("ginger"), Int32.Parse(ginger.Text)));
            int n=Program.assistant.newOrder(subnum.Text, Int32.Parse(time.Text), items);
            if(n == 1)
            {
                MessageBox.Show("هیچ زمانی پذیرا نیست");
            }
            if (n == 2)
            {
                MessageBox.Show("لطفا اعتبار را افزایش دهید");
            }
            if (n >2)
            {
                MessageBox.Show("این ساعت را انتخاب کنید:"+n);
            }
            bindingSource.ResetBindings(false);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Order order = (Order)dataGridView1.CurrentRow.DataBoundItem;
            List<Customer> customer=(from c in Assistant.customers where c.SubNum==order.OrderGiver select c).ToList();
            customer[0].Credit += order.Price;
            customer[0].Bought -= order.Price;
            Assistant.orders.Remove(order);
            bindingSource.ResetBindings(false);

        }
    }
}
