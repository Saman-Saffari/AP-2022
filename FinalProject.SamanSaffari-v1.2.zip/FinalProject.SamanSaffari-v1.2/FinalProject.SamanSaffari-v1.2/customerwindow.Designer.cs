﻿namespace FinalProject.SamanSaffari_v1._2
{
    partial class customerwindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstname = new System.Windows.Forms.TextBox();
            this.phonenum = new System.Windows.Forms.TextBox();
            this.bankacc = new System.Windows.Forms.TextBox();
            this.lastname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.newcustomer = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.searchbox = new System.Windows.Forms.TextBox();
            this.increase = new System.Windows.Forms.Button();
            this.increasevalue = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.sum = new System.Windows.Forms.Button();
            this.goodcustomers = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // firstname
            // 
            this.firstname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.firstname.Location = new System.Drawing.Point(615, 8);
            this.firstname.Name = "firstname";
            this.firstname.Size = new System.Drawing.Size(111, 26);
            this.firstname.TabIndex = 0;
            this.firstname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // phonenum
            // 
            this.phonenum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.phonenum.Location = new System.Drawing.Point(391, 52);
            this.phonenum.Name = "phonenum";
            this.phonenum.Size = new System.Drawing.Size(111, 26);
            this.phonenum.TabIndex = 1;
            // 
            // bankacc
            // 
            this.bankacc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.bankacc.Location = new System.Drawing.Point(391, 9);
            this.bankacc.Name = "bankacc";
            this.bankacc.Size = new System.Drawing.Size(111, 26);
            this.bankacc.TabIndex = 2;
            // 
            // lastname
            // 
            this.lastname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lastname.Location = new System.Drawing.Point(615, 47);
            this.lastname.Name = "lastname";
            this.lastname.Size = new System.Drawing.Size(111, 26);
            this.lastname.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(801, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 39);
            this.label1.TabIndex = 4;
            this.label1.Text = "نام";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(731, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "نام خانوادگی";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(508, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 27);
            this.label3.TabIndex = 6;
            this.label3.Text = "شماره کارت";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(508, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 32);
            this.label4.TabIndex = 7;
            this.label4.Text = "شماره تلفن";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // newcustomer
            // 
            this.newcustomer.BackColor = System.Drawing.Color.DarkKhaki;
            this.newcustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.newcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newcustomer.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.newcustomer.Location = new System.Drawing.Point(244, 8);
            this.newcustomer.Name = "newcustomer";
            this.newcustomer.Size = new System.Drawing.Size(128, 70);
            this.newcustomer.TabIndex = 8;
            this.newcustomer.Text = "ایجاد مشترک";
            this.newcustomer.UseVisualStyleBackColor = false;
            this.newcustomer.Click += new System.EventHandler(this.newcustomer_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Bisque;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.BlanchedAlmond;
            this.dataGridView1.Location = new System.Drawing.Point(12, 244);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(809, 222);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseDoubleClick);
            // 
            // searchbox
            // 
            this.searchbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.searchbox.Location = new System.Drawing.Point(391, 204);
            this.searchbox.Name = "searchbox";
            this.searchbox.Size = new System.Drawing.Size(172, 26);
            this.searchbox.TabIndex = 10;
            this.searchbox.TextChanged += new System.EventHandler(this.searchbox_TextChanged);
            // 
            // increase
            // 
            this.increase.BackColor = System.Drawing.Color.Khaki;
            this.increase.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.increase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.increase.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.increase.Location = new System.Drawing.Point(12, 8);
            this.increase.Name = "increase";
            this.increase.Size = new System.Drawing.Size(207, 41);
            this.increase.TabIndex = 11;
            this.increase.Text = "افزایش اعتبار مشتری";
            this.increase.UseVisualStyleBackColor = false;
            this.increase.Click += new System.EventHandler(this.increase_Click);
            // 
            // increasevalue
            // 
            this.increasevalue.BackColor = System.Drawing.Color.LemonChiffon;
            this.increasevalue.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.increasevalue.Location = new System.Drawing.Point(12, 52);
            this.increasevalue.Name = "increasevalue";
            this.increasevalue.Size = new System.Drawing.Size(107, 26);
            this.increasevalue.TabIndex = 12;
            this.increasevalue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(125, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 26);
            this.label5.TabIndex = 13;
            this.label5.Text = "مقدار افزایش";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(601, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(220, 38);
            this.label6.TabIndex = 14;
            this.label6.Text = "جستجو بر اساس کد اشتراک";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // sum
            // 
            this.sum.BackColor = System.Drawing.Color.Khaki;
            this.sum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.sum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sum.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.sum.Location = new System.Drawing.Point(12, 197);
            this.sum.Name = "sum";
            this.sum.Size = new System.Drawing.Size(207, 41);
            this.sum.TabIndex = 15;
            this.sum.Text = "مجموع اعتبار مشتریان";
            this.sum.UseVisualStyleBackColor = false;
            this.sum.Click += new System.EventHandler(this.sum_Click);
            // 
            // goodcustomers
            // 
            this.goodcustomers.BackColor = System.Drawing.Color.Khaki;
            this.goodcustomers.FormattingEnabled = true;
            this.goodcustomers.Location = new System.Drawing.Point(12, 101);
            this.goodcustomers.Name = "goodcustomers";
            this.goodcustomers.Size = new System.Drawing.Size(121, 28);
            this.goodcustomers.TabIndex = 16;
            this.goodcustomers.SelectedIndexChanged += new System.EventHandler(this.goodcustomers_SelectedIndexChanged);
            // 
            // customerwindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(833, 489);
            this.Controls.Add(this.goodcustomers);
            this.Controls.Add(this.sum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.increasevalue);
            this.Controls.Add(this.increase);
            this.Controls.Add(this.searchbox);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.newcustomer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lastname);
            this.Controls.Add(this.bankacc);
            this.Controls.Add(this.phonenum);
            this.Controls.Add(this.firstname);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Name = "customerwindow";
            this.Text = "customerwindow";
            this.Load += new System.EventHandler(this.customerwindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstname;
        private System.Windows.Forms.TextBox phonenum;
        private System.Windows.Forms.TextBox bankacc;
        private System.Windows.Forms.TextBox lastname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button newcustomer;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox searchbox;
        private System.Windows.Forms.Button increase;
        private System.Windows.Forms.TextBox increasevalue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button sum;
        private System.Windows.Forms.ComboBox goodcustomers;
    }
}