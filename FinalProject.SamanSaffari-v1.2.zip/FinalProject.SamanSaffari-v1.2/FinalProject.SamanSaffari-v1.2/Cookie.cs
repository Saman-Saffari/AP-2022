﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.SamanSaffari_v1._2
{
    internal class Cookie : Iitem
    {
        public string Name { get; set; }

        public int Price { get; set; }
        public Cookie(string name, int price)
        {
            Name = name;
            Price = price;
        }
    }
}
