﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.SamanSaffari_v1._2
{
    public partial class customerwindow : Form
    {
        BindingSource bindingSource = new BindingSource();

        
        public customerwindow()
        {


            InitializeComponent();

        }
        private void customerwindow_Load(object sender, EventArgs e)
        {
            bindingSource.DataSource = Assistant.customers;
            dataGridView1.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
            goodcustomers.Items.Add("500");
            goodcustomers.Items.Add("1000");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void bankacc_TextChanged(object sender, EventArgs e)
        {

        }

        private void newcustomer_Click(object sender, EventArgs e)
        {
            Assistant.newcustomer(firstname.Text, lastname.Text, bankacc.Text, phonenum.Text);
            bindingSource.ResetBindings(false);


        }

        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            firstname.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            lastname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            bankacc.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            phonenum.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {

            bindingSource.DataSource = Program.assistant.search(searchbox.Text); ;
            dataGridView1.DataSource = bindingSource;
            bindingSource.ResetBindings(false);

        }

        private void increase_Click(object sender, EventArgs e)
        {
            Customer customer = (Customer)dataGridView1.CurrentRow.DataBoundItem;
            customer.increaseCredit(Int32.Parse(increasevalue.Text));
            MessageBox.Show(customer.Credit.ToString()+"   :"+customer.SubNum+" اعتبار جدید کاربر");
            
        }

        private void sum_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Program.assistant.sum().ToString());
        }

        private void goodcustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindingSource.DataSource=Program.assistant.goodcustomers(Int32.Parse(goodcustomers.Text));
            dataGridView1.DataSource = bindingSource;
            bindingSource.ResetBindings(false);

        }
    }
}
