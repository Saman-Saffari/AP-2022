﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.SamanSaffari_v1._2
{
    internal class Order
    {
        public static int Ordernum { get; set; } = 1;
        public int Time { get; set; }
        public string Orderid { get; set; }
        public string OrderGiver { get; set; }
        public int Price { get; set; }
        public int Num { get; set; }
        public List<KeyValuePair<Iitem, int>> items=new List<KeyValuePair<Iitem, int>>();
       
        public Order(string subnum, int time)
        {
            this.Time = time;
            this.OrderGiver = subnum;
            this.Orderid = orderId();
            this.Num = Ordernum;

        }

        private string orderId()
        {
            bool isOk = false;
            bool check = false;
            string id = null;
            while (isOk == false)
            {
                Random r = new Random();
                var x = r.Next(0, 1000000);
                string s = x.ToString("000000");
                for (int i = 0; i < Assistant.customers.Count; i++)
                {
                    if (s == Assistant.customers[i].SubNum)
                    {
                        check = true;
                    }
                }
                if (check == false)
                {
                    isOk = true;
                    id = s;
                }
            }
            return id;
        }
        public int price()
        {
            int price = 0;
            foreach (var item in items)
            {
                price =price+ item.Key.Price*item.Value;
            }
            return price;
        }
    }
}
