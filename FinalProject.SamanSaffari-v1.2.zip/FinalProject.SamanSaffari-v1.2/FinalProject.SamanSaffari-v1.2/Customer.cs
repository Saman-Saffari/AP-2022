﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.SamanSaffari_v1._2
{
    internal class Customer
    {
        public Customer(string firstname, string lastname, string bankacc, string phonenum)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.BankAcc = bankacc;
            this.PhoneNum = phonenum;
            this.SubNum = subnum();
            this.Credit = 0;
            this.Bought = 0;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string BankAcc { get; set; }
        public string SubNum { get; set; }
        public string PhoneNum { get; set; }
        public int Bought { get; set; }
        private int credit;
        public int Credit
        {
            get { return credit; }
            set
            {
                if (value > 0)
                {
                    credit = value;
                }
                else { credit = 0; }
            }
        }

        public void increaseCredit(int increase)
        {
            if (this.credit + increase >=0) { this.credit = this.credit + increase; }
        }
        private void order(IOrder order)
        {

        }
        private string subnum()
        {
            bool isOk = false;
            bool check=false;
            string sub = null;
            while (isOk == false)
            {
                Random r = new Random();
                var x = r.Next(0, 1000000);
                string s = x.ToString("000000");
                for(int i = 0; i < Assistant.customers.Count; i++)
                {
                    if (s == Assistant.customers[i].SubNum)
                    {
                        check = true;
                    }
                }
                if (check == false)
                {
                    isOk = true;
                    sub = s;
                }
            }
            return sub;
        }
    }
}
