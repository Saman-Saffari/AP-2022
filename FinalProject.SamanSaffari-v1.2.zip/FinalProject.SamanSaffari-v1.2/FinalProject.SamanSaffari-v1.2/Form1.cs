﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.SamanSaffari_v1._2
{
    public partial class Form1 : Form
    {
        BindingSource bindingSource = new BindingSource();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void CustomerClick(object sender, EventArgs e)
        {
            customerwindow customerwindow = new customerwindow();
            customerwindow.Show();
        }

        private void OrderClick(object sender, EventArgs e)
        {
            orderwindow orderwindow = new orderwindow();
            orderwindow.Show();
        }
    }
}
