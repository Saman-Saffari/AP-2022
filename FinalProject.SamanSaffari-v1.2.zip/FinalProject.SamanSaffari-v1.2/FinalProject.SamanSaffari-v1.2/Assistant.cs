﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.SamanSaffari_v1._2
{
    internal class Assistant
    {
        public static List<Customer> customers=new List<Customer>();
        public static List<Order> orders=new List<Order>();
        public static int ordersum()
        {
            int sum = 0;
            for(int i = 0; i < orders.Count; i++)
            {
                for(int j = 0; j < orders[i].items.Count; j++)
                {
                    sum += orders[i].items[j].Value;
                }
            }
            return sum;
        }
        public static int hoursum(int time)
        {
            int sum = 0;
            for (int i = 0; i < orders.Count; i++)
            {
                if (orders[i].Time == time)
                {
                    for (int j = 0; j < orders[i].items.Count; j++)
                    {
                        sum += orders[i].items[j].Value;
                    }
                }

            }
            return sum;
        }
        public static void newcustomer(string firstname, string lastname, string bankacc, string phonenum)
        {
            Customer customer = new Customer(firstname, lastname, bankacc,phonenum);
            customers.Add(customer);
            
        }

        public List<Customer> search(string text)
        {
            List<Customer> searchCustomer=new List<Customer>();
            searchCustomer=(from customer in customers where customer.SubNum.Contains(text) select customer).ToList();
            return searchCustomer;
        }

        public int sum()
        {
            int sum=0;
            foreach (Customer customer in customers)
            {
                sum += customer.Credit;
            }
            return sum;
        }
        public List<Customer> goodcustomers(int num)
        {
            List<Customer> goodCustomer = new List<Customer>();
            goodCustomer = (from customer in customers where customer.Bought>=num select customer).ToList();
            return goodCustomer;
        }
        public int newOrder(string subnum, int time, List<KeyValuePair<Iitem, int>> items)
        {
            Order order = new Order(subnum, time);
            order.items = items;
            order.Price = order.price();
            int sum = 0;
            foreach (KeyValuePair<Iitem, int> item in items)
            {
                sum+=item.Value;
            }
            List<Customer> ordergiver = (from customer in customers where customer.SubNum == subnum select customer).ToList();
            if (ordergiver[0].Credit < order.Price)
            {
                return 2;
            }
            else if (sum >=(1000 - hoursum(time)))
            {
                int newtime=time;
                for (int i = 6; i < 21; i++)
                {
                    if (sum < (1000 - hoursum(i)))
                    {
                        newtime = i;
                    }
                }
                if (newtime == time)
                {
                    return 1;
                }
                else { return newtime; }

            }
            else
            {
                orders.Add(order);
                Order.Ordernum++;
                ordergiver[0].Credit-=order.Price;
                ordergiver[0].Bought+=order.Price;
                return 0;
            }

        }
    }


}
