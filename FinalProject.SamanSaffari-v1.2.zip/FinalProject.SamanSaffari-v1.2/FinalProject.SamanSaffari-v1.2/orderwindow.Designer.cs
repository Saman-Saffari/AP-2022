﻿namespace FinalProject.SamanSaffari_v1._2
{
    partial class orderwindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.plain = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.saffron = new System.Windows.Forms.TextBox();
            this.raisin = new System.Windows.Forms.TextBox();
            this.chocolate = new System.Windows.Forms.TextBox();
            this.ginger = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.neworder = new System.Windows.Forms.Button();
            this.subnum = new System.Windows.Forms.TextBox();
            this.time = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // plain
            // 
            this.plain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.plain.Location = new System.Drawing.Point(676, 8);
            this.plain.Name = "plain";
            this.plain.Size = new System.Drawing.Size(61, 26);
            this.plain.TabIndex = 6;
            this.plain.Text = "0";
            this.plain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(743, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "ساده";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(167, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "زعفرانی";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(606, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "زنجبیلی";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(322, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "کشمشی";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(466, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 25);
            this.label5.TabIndex = 11;
            this.label5.Text = "شکلاتی";
            // 
            // saffron
            // 
            this.saffron.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.saffron.Location = new System.Drawing.Point(100, 8);
            this.saffron.Name = "saffron";
            this.saffron.Size = new System.Drawing.Size(61, 26);
            this.saffron.TabIndex = 12;
            this.saffron.Text = "0";
            this.saffron.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // raisin
            // 
            this.raisin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.raisin.Location = new System.Drawing.Point(255, 8);
            this.raisin.Name = "raisin";
            this.raisin.Size = new System.Drawing.Size(61, 26);
            this.raisin.TabIndex = 13;
            this.raisin.Text = "0";
            this.raisin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // chocolate
            // 
            this.chocolate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.chocolate.Location = new System.Drawing.Point(399, 8);
            this.chocolate.Name = "chocolate";
            this.chocolate.Size = new System.Drawing.Size(61, 26);
            this.chocolate.TabIndex = 14;
            this.chocolate.Text = "0";
            this.chocolate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ginger
            // 
            this.ginger.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ginger.Location = new System.Drawing.Point(539, 8);
            this.ginger.Name = "ginger";
            this.ginger.Size = new System.Drawing.Size(61, 26);
            this.ginger.TabIndex = 15;
            this.ginger.Text = "0";
            this.ginger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(38, 163);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(721, 266);
            this.dataGridView1.TabIndex = 16;
            // 
            // neworder
            // 
            this.neworder.BackColor = System.Drawing.Color.Khaki;
            this.neworder.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neworder.Location = new System.Drawing.Point(227, 54);
            this.neworder.Name = "neworder";
            this.neworder.Size = new System.Drawing.Size(136, 38);
            this.neworder.TabIndex = 17;
            this.neworder.Text = "ایجاد سفارش";
            this.neworder.UseVisualStyleBackColor = false;
            this.neworder.Click += new System.EventHandler(this.neworder_Click);
            // 
            // subnum
            // 
            this.subnum.Location = new System.Drawing.Point(399, 61);
            this.subnum.Name = "subnum";
            this.subnum.Size = new System.Drawing.Size(100, 26);
            this.subnum.TabIndex = 18;
            // 
            // time
            // 
            this.time.Location = new System.Drawing.Point(627, 62);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(100, 26);
            this.time.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(733, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 25);
            this.label6.TabIndex = 20;
            this.label6.Text = "ساعت";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(505, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 25);
            this.label7.TabIndex = 21;
            this.label7.Text = "کد کاربر";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(65, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 39);
            this.button1.TabIndex = 22;
            this.button1.Text = "حذف سفارش";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // orderwindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(796, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.time);
            this.Controls.Add(this.subnum);
            this.Controls.Add(this.neworder);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ginger);
            this.Controls.Add(this.chocolate);
            this.Controls.Add(this.raisin);
            this.Controls.Add(this.saffron);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.plain);
            this.Name = "orderwindow";
            this.Text = "orderwindow";
            this.Load += new System.EventHandler(this.orderwindow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox plain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox saffron;
        private System.Windows.Forms.TextBox raisin;
        private System.Windows.Forms.TextBox chocolate;
        private System.Windows.Forms.TextBox ginger;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button neworder;
        private System.Windows.Forms.TextBox subnum;
        private System.Windows.Forms.TextBox time;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
    }
}