﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal class Theatre : ITheatre
    {
        public string Name { get; set; }

        public int Capacity { get; set; }
        public Theatre(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
        }
        public override string ToString()
        {
            return this.Name;
        }
    }
}
