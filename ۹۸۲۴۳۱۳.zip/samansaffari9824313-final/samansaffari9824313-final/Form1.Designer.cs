﻿namespace samansaffari9824313_final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.newseance = new System.Windows.Forms.Button();
            this.buy = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ticket_num = new System.Windows.Forms.TextBox();
            this.cinemamake = new System.Windows.Forms.Button();
            this.cinemacap = new System.Windows.Forms.TextBox();
            this.cinemaname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.filmname = new System.Windows.Forms.TextBox();
            this.filmgenre = new System.Windows.Forms.TextBox();
            this.filmmake = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.owner = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ticketprice = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(51, 108);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(747, 264);
            this.listBox1.TabIndex = 0;
            this.listBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(746, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "شروع";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(751, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "پایان";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(330, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "مکان";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(169, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "فیلم";
            // 
            // newseance
            // 
            this.newseance.Location = new System.Drawing.Point(51, 55);
            this.newseance.Name = "newseance";
            this.newseance.Size = new System.Drawing.Size(122, 35);
            this.newseance.TabIndex = 9;
            this.newseance.Text = "ایجاد سانس";
            this.newseance.UseVisualStyleBackColor = true;
            this.newseance.Click += new System.EventHandler(this.newseance_Click);
            this.newseance.MouseClick += new System.Windows.Forms.MouseEventHandler(this.newseance_MouseClick);
            // 
            // buy
            // 
            this.buy.Location = new System.Drawing.Point(51, 378);
            this.buy.Name = "buy";
            this.buy.Size = new System.Drawing.Size(127, 29);
            this.buy.TabIndex = 10;
            this.buy.Text = "خرید بلیط";
            this.buy.UseVisualStyleBackColor = true;
            this.buy.Click += new System.EventHandler(this.buy_Click);
            this.buy.MouseClick += new System.Windows.Forms.MouseEventHandler(this.newseance_MouseClick);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(574, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(166, 26);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(574, 57);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(166, 26);
            this.dateTimePicker2.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(720, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "ایجاد سانس";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(587, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(211, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "خرید بلیط - دوبار روی سانس کلیک کنید";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(727, 378);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "تعداد بلیط:";
            // 
            // ticket_num
            // 
            this.ticket_num.Location = new System.Drawing.Point(610, 378);
            this.ticket_num.Name = "ticket_num";
            this.ticket_num.Size = new System.Drawing.Size(100, 26);
            this.ticket_num.TabIndex = 16;
            // 
            // cinemamake
            // 
            this.cinemamake.Location = new System.Drawing.Point(51, 478);
            this.cinemamake.Name = "cinemamake";
            this.cinemamake.Size = new System.Drawing.Size(127, 36);
            this.cinemamake.TabIndex = 17;
            this.cinemamake.Text = "ایجاد سینما";
            this.cinemamake.UseVisualStyleBackColor = true;
            this.cinemamake.Click += new System.EventHandler(this.cinemamake_Click);
            // 
            // cinemacap
            // 
            this.cinemacap.Location = new System.Drawing.Point(610, 488);
            this.cinemacap.Name = "cinemacap";
            this.cinemacap.Size = new System.Drawing.Size(100, 26);
            this.cinemacap.TabIndex = 18;
            // 
            // cinemaname
            // 
            this.cinemaname.Location = new System.Drawing.Point(422, 488);
            this.cinemaname.Name = "cinemaname";
            this.cinemaname.Size = new System.Drawing.Size(100, 26);
            this.cinemaname.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(730, 494);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "ظرفیت";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(546, 497);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 20);
            this.label9.TabIndex = 21;
            this.label9.Text = "نام";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(720, 459);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 20);
            this.label10.TabIndex = 22;
            this.label10.Text = "ایجاد سینما";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(228, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(96, 28);
            this.comboBox1.TabIndex = 23;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(722, 537);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 20);
            this.label11.TabIndex = 29;
            this.label11.Text = "ایجاد فیلم";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(548, 575);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 20);
            this.label12.TabIndex = 28;
            this.label12.Text = "نام";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(732, 572);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 20);
            this.label13.TabIndex = 27;
            this.label13.Text = "ژانر";
            // 
            // filmname
            // 
            this.filmname.Location = new System.Drawing.Point(422, 569);
            this.filmname.Name = "filmname";
            this.filmname.Size = new System.Drawing.Size(100, 26);
            this.filmname.TabIndex = 26;
            this.filmname.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // filmgenre
            // 
            this.filmgenre.Location = new System.Drawing.Point(612, 566);
            this.filmgenre.Name = "filmgenre";
            this.filmgenre.Size = new System.Drawing.Size(100, 26);
            this.filmgenre.TabIndex = 25;
            // 
            // filmmake
            // 
            this.filmmake.Location = new System.Drawing.Point(51, 559);
            this.filmmake.Name = "filmmake";
            this.filmmake.Size = new System.Drawing.Size(127, 36);
            this.filmmake.TabIndex = 24;
            this.filmmake.Text = "ایجاد فیلم";
            this.filmmake.UseVisualStyleBackColor = true;
            this.filmmake.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(67, 21);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(96, 28);
            this.comboBox2.TabIndex = 30;
            // 
            // owner
            // 
            this.owner.Location = new System.Drawing.Point(422, 379);
            this.owner.Name = "owner";
            this.owner.Size = new System.Drawing.Size(100, 26);
            this.owner.TabIndex = 31;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(528, 379);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 20);
            this.label14.TabIndex = 32;
            this.label14.Text = "نام خریدار";
            // 
            // ticketprice
            // 
            this.ticketprice.Location = new System.Drawing.Point(390, 25);
            this.ticketprice.Name = "ticketprice";
            this.ticketprice.Size = new System.Drawing.Size(100, 26);
            this.ticketprice.TabIndex = 33;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(496, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 20);
            this.label15.TabIndex = 34;
            this.label15.Text = "قیمت بلیط:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 628);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.ticketprice);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.owner);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.filmname);
            this.Controls.Add(this.filmgenre);
            this.Controls.Add(this.filmmake);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cinemaname);
            this.Controls.Add(this.cinemacap);
            this.Controls.Add(this.cinemamake);
            this.Controls.Add(this.ticket_num);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.buy);
            this.Controls.Add(this.newseance);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button newseance;
        private System.Windows.Forms.Button buy;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ticket_num;
        private System.Windows.Forms.Button cinemamake;
        private System.Windows.Forms.TextBox cinemacap;
        private System.Windows.Forms.TextBox cinemaname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox filmname;
        private System.Windows.Forms.TextBox filmgenre;
        private System.Windows.Forms.Button filmmake;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox owner;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox ticketprice;
        private System.Windows.Forms.Label label15;
    }
}

