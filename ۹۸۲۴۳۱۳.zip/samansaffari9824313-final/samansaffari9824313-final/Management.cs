﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal class Management
    {
        public List<ITheatre> theatres=new List<ITheatre>();
        public void CreateTheatre(string name,int capacity)
        {
            ITheatre theatre = new Theatre(name,capacity);
            theatres.Add(theatre);
        }

        public List<Seance> seances = new List<Seance>();
        public void CreateSeance(DateTime start,DateTime end, ITheatre theatre, IMovie movie,int price)
        {
            Seance seance = new Seance(start, end, theatre, movie,price);
            seances.Add(seance);
        }

        public List <IMovie> movies= new List<IMovie>();
        public void CreateMovie(string genre1,string name1)
        {
            IMovie movie=new Movie(genre1,name1);
            movies.Add(movie);
        }


        public List<ITicket> tickets = new List<ITicket>();
        public void CreateTicket(Seance seance,string owner,int price)
        {
            ITicket ticket = new Ticket(seance, owner, price);
            tickets.Add(ticket);
        }


        public delegate void SellHandler(object sender, EventArgs e);
        public event SellHandler Sold;
        public void sell()
        {
            OnSold();
        }
        protected virtual void OnSold()
        {
            if(Sold != null)
            {
                Sold(this, EventArgs.Empty);
            }
        }
    }
}
