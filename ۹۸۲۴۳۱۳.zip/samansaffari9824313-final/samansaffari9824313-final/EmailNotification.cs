﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal class EmailNotification : Notification // Singleton Design Pattern
    {
        private EmailNotification() { }
        private static EmailNotification instance;
        public static EmailNotification GetInstance()
        {
            if (instance == null)
            {
                instance = new EmailNotification();
            }
            return instance;
        }
        public void Send(string message, string reciever, DateTime time)
        {
            throw new NotImplementedException();
        }
    }
}
