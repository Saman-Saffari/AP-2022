﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace samansaffari9824313_final
{
    public partial class Form1 : Form

    {
        Seance seancesave = null;
        BindingSource combobindingSource=new BindingSource();
        BindingSource combo2bindingSource=new BindingSource();
        BindingSource listboxbindingSource = new BindingSource();
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            combobindingSource.DataSource = Program.management.theatres;
            comboBox1.DataSource = combobindingSource;
            comboBox1.DisplayMember=ToString();


            combo2bindingSource.DataSource = Program.management.movies;
            comboBox2.DataSource = combo2bindingSource;
            comboBox2.DisplayMember = ToString();

            listboxbindingSource.DataSource = Program.management.seances;
            listBox1.DataSource = listboxbindingSource;
            listBox1.DisplayMember = ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void theatre_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void end_TextChanged(object sender, EventArgs e)
        {

        }



        private void newseance_Click(object sender, EventArgs e)
        {
            ITheatre t = null;
            IMovie m = null;
            foreach (var item in Program.management.theatres)
            {
                if (comboBox1.SelectedItem.ToString() == item.Name)
                    t = item;
            }
            foreach (var item in Program.management.movies)
            {
                if (comboBox2.SelectedItem.ToString() == item.Name)
                    m = item;
            }

            Program.management.CreateSeance(dateTimePicker1.Value.Date, dateTimePicker2.Value.Date, t, m,Int32.Parse(ticketprice.Text));
            //CHECK
            listboxbindingSource.ResetBindings(false);
        }

        private void newseance_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void cinemamake_Click(object sender, EventArgs e)
        {
            try
            {
                Program.management.CreateTheatre(cinemaname.Text, Int32.Parse(cinemacap.Text));
            }
            catch(Exception ex)
            {
                Console.WriteLine($"{ ex.Message}--fill the fields");
            }


            combobindingSource.ResetBindings(false);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Program.management.CreateMovie(filmname.Text, filmgenre.Text);

            combo2bindingSource.ResetBindings(false);
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Seance x=(sender as ListBox).SelectedItem as Seance;
            if(x != null)
            {
                seancesave = x;
            }

        }
        private void buy_Click(object sender, EventArgs e)
        {
            if(seancesave.capacity > 0)
            {
                for (int i = 0; i < Int32.Parse(ticket_num.Text); i++)
                {
                    Program.management.CreateTicket(seancesave, owner.Text, Int32.Parse(ticketprice.Text));
                    seancesave.capacity--;
                }
            }
            listboxbindingSource.ResetBindings(false);
        }
    }
}
