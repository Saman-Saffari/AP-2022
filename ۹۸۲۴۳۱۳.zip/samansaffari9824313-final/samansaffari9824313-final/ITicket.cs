﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal interface ITicket
    {
        Seance seance { get; }
        string Owner { get; }
        int Price { get; }
    }
}
