﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal interface IMovie
    {
        string Name { get; }
        string Genre { get; }


    }
}
