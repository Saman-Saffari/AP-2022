﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal class Seance
    {
        private DateTime start { get; set; }
        private DateTime end { get; set; }
        public ITheatre theatre { get; set; }
        public IMovie movie { get; set; }
        public int capacity { get; set; }
        public int price { get; set; } = 0;
        public Seance(DateTime start1,DateTime end1,ITheatre theatre1, IMovie movie1,int price1)
        {
            this.start = start1;
            this.end = end1;
            this.theatre = theatre1;
            this.movie = movie1;
            this.price = price1;
            try
            {
                this.capacity = theatre1.Capacity;
            }
            catch (NullReferenceException exception)
            {
                Console.WriteLine($"{exception.Message} -- fill all fields");
            }
        }
        public void OnSold(object source, EventArgs e)
        {
            this.capacity = this.capacity - 1;
        }
        public override string ToString()
        {
            return $"{this.start.ToString()}\t{this.end.ToString()}\t{this.theatre.Name}\t{this.movie.Name}\t{this.price}\t{this.capacity}";
        }
    }
}
