﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal class Ticket : ITicket
    {
        public Seance seance { get; set; }

        public string Owner { get; set; }
        public int Price { get; set; }
        public Ticket(Seance seance1, string owner1,int price1)
        {
            this.seance = seance1;
            this.Owner = owner1;
            this.Price = price1;
        }
    }
}
