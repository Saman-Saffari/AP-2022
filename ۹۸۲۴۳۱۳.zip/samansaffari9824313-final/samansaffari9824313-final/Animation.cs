﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samansaffari9824313_final
{
    internal class Animation : IMovie
    {
        public string Name { get; set; }

        public string Genre { get; set; }
    }
}
